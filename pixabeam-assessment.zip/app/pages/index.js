export default function Home() {
  return (
    <div className="p-6 text-center">
      <h1 className="text-3xl font-bold">Welcome to Pixabeam Assessment</h1>
      <p className="mt-4">Deployed on Vercel with Supabase backend.</p>
    </div>
  );
}
